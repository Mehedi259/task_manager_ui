import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:task_manager/utils/app_colors.dart';

class CustomTextfield extends StatefulWidget {
  final String? title;
  final TextEditingController? controller;
  final String? hintText;
  final bool isPass;
  const CustomTextfield({
    super.key,
    this.title,
    this.controller,
    this.hintText,
    this.isPass = false,
  });

  @override
  State<CustomTextfield> createState() => _CustomTextfieldState();
}

class _CustomTextfieldState extends State<CustomTextfield> {
  bool isObscured = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(width: 14.w),
        if (widget.title != null)
          Text(
            widget.title!,
            style: TextStyle(
              fontWeight: FontWeight.w500,
              fontSize: 14.h,
              color: AppColors.primaryTextColor,
            ),
          ),

        SizedBox(height: 6.h),

        Container(
          height: 44.h,
          decoration: BoxDecoration(
            color: AppColors.softBrandColor,
            borderRadius: BorderRadius.circular(6),
            boxShadow: [
              BoxShadow(
                offset: Offset(1, 1),
                blurRadius: 24,
                color: Colors.black.withValues(alpha: 0.1),
              ),
            ],
          ),

          child: Row(
            children: [
              SizedBox(width: 14.w),
              Expanded(
                child: TextField(
                  controller: widget.controller,
                  obscureText: widget.isPass,
                  cursorColor: AppColors.brandColor,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: widget.hintText,
                    isCollapsed: true,
                    isDense: true,
                    hintStyle: TextStyle(
                      color: AppColors.secondaryTextColor,
                      fontSize: 16.h,
                    ),
                  ),
                ),
              ),
              if (widget.isPass)
                IconButton(
                  onPressed: () {
                    setState(() {
                      isObscured = !isObscured;
                    });
                  },
                  icon: isObscured
                      ? Icon(Icons.visibility_off_outlined)
                      : Icon(Icons.visibility_outlined),
                ),

              SizedBox(width: 14.w),
            ],
          ),
        ),
      ],
    );
  }
}
