import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:task_manager/utils/app_colors.dart';

class CustomNavbar extends StatefulWidget implements PreferredSizeWidget {
  final int index;
  final void Function(int) onChanged;
  const CustomNavbar({super.key, required this.index, required this.onChanged});

  @override
  CustomNavbarState createState() => CustomNavbarState();

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight); // You can adjust the height here.
}

class CustomNavbarState extends State<CustomNavbar> {
  List<String> pages = ["My Tasks", "Add Task", "Profile"];
  List<String> assets = ["home", "add_task", "profile"];

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          width: double.infinity,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
            boxShadow: [
              BoxShadow(
                blurRadius: 24,
                offset: Offset(0, 1),
                color: Colors.black.withValues(alpha: 0.15),
              ),
            ],
          ),
          child: SafeArea(child: SizedBox(height: 64.h)),
        ),
        Positioned(
          top: -12.h,
          left: 0,
          right: 0,
          child: Row(
            children: [
              Spacer(),
              button(0),
              Spacer(flex: 2,),
              button(1),
              Spacer(flex: 2,),
              button(2),
              Spacer(),
            ],
          ),
        ),
      ],
    );
  }

  Widget button(int pos) {
    bool isSelected = pos == widget.index;

    return GestureDetector(
      onTap: () {
        widget.onChanged(pos);
      },
      behavior: HitTestBehavior.translucent,
      child: Column(
        children: [
          if (!isSelected) SizedBox(height: 11),
          Container(
            height: isSelected ? 64.h : 24.h,
            width: 64.h,
            decoration: BoxDecoration(
              color: isSelected ? AppColors.brandColor : Colors.transparent,
              border: isSelected
                  ? Border.all(color: Colors.white, width: 6)
                  : null,
              shape: BoxShape.circle,
            ),
            child: Center(
              child: SvgPicture.asset(
                "assets/icons/${assets[pos]}.svg",
                // ignore: deprecated_member_use
                color: isSelected ? Colors.white : Colors.black,
              ),
            ),
          ),
          if (!isSelected)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                pages[pos],
                style: TextStyle(fontSize: 12.h, color: Color(0xff1E293B)),
              ),
            ),
        ],
      ),
    );
  }
}
