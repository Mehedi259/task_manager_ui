import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:task_manager/pages/otp.dart';
import 'package:task_manager/utils/app_colors.dart';
import 'package:task_manager/widgets/custom_button.dart';
import 'package:task_manager/widgets/custom_textfield.dart';

class Verify extends StatelessWidget {
  const Verify({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Align(
        alignment: Alignment.center,
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsetsGeometry.symmetric(horizontal: 16.h),
            child: Column(
              children: [
                Column(
                  children: [
                    Text(
                      "Verify Your Email",
                      style: TextStyle(
                        color: AppColors.primaryTextColor,
                        fontWeight: FontWeight.w500,
                        fontSize: 30.w,
                      ),
                    ),
                    SizedBox(height: 8.h),
                    Text(
                      "We'll send a verification code to this email to confirm your account.",
                      style: TextStyle(
                        color: AppColors.secondaryTextColor,
                        fontSize: 14.h,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 23.h),
                CustomTextfield(
                  title: "Email Address",
                  hintText: "michelle.rivera@example.com",
                ),
                SizedBox(height: 60.h),
                CustomButton(
                  text: "Send",
                  onClick: () {
                    Get.to(() => Otp());
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
