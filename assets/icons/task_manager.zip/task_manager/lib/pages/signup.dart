import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/route_manager.dart';
import 'package:task_manager/pages/verify.dart';
import 'package:task_manager/utils/app_colors.dart';
import 'package:task_manager/widgets/custom_button.dart';
import 'package:task_manager/widgets/custom_textfield.dart';

class Signup extends StatefulWidget {
  const Signup({super.key});

  @override
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  bool accept = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Align(
          alignment: Alignment.center,
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Column(
                spacing: 23.h,
                children: [
                  Column(
                    children: [
                      Text(
                        "Create Your Account",
                        style: TextStyle(
                          color: AppColors.primaryTextColor,
                          fontWeight: FontWeight.w500,
                          fontSize: 30.w,
                        ),
                      ),
                      SizedBox(height: 8.h),
                      Text(
                        "Join Task Manager today — organize better, work smarter, and stay in control of your day.",
                        style: TextStyle(
                          color: AppColors.secondaryTextColor,
                          fontSize: 14.h,
                        ),
                      ),
                    ],
                  ),

                  CustomTextfield(
                    title: "First Name",
                    hintText: "e.g. Kristin",
                  ),
                  CustomTextfield(title: "Last Name", hintText: "e.g. Cooper"),
                  CustomTextfield(
                    title: "Email Address",
                    hintText: "e.g. kristin.cooper@example.com",
                  ),
                  CustomTextfield(
                    title: "Address",
                    hintText: "e.g. 1234 Elm Street, Springfield, IL",
                  ),
                  CustomTextfield(title: "PassWord", isPass: true),
                  Column(
                    spacing: 6.h,
                    children: [
                      CustomTextfield(title: "Confirm PassWord", isPass: true),
                      Row(
                        children: [
                          GestureDetector(
                            onTap: () {
                              setState(() {
                                accept = !accept;
                              });
                            },
                            behavior: HitTestBehavior.translucent,
                            child: SvgPicture.asset(
                              "assets/icons/${accept ? "" : "un"}check.svg",
                            ),
                          ),
                          SizedBox(width: 6.h),
                          Text(
                            "I agree to the Terms & Conditions and Privacy Policy.",
                            style: TextStyle(
                              fontSize: 12.h,
                              color: Color(0xff344054),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),

                  Row(
                    spacing: 8.h,
                    children: [
                      Expanded(
                        child: Divider(color: Color(0xff64748B), height: 1.5),
                      ),
                      Text(
                        "OR",
                        style: TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 14.h,
                          color: Color(0xff0A0E23),
                        ),
                      ),
                      Expanded(
                        child: Divider(color: Color(0xff64748B), height: 1.5),
                      ),
                    ],
                  ),
                  Row(
                    spacing: 4,
                    children: [
                      Text(
                        "Already have an account?",
                        style: TextStyle(
                          fontSize: 14.h,
                          color: Color(0xff344054),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {},
                        behavior: HitTestBehavior.translucent,
                        child: Text(
                          "Log In",
                          style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: 14.h,
                            color: AppColors.brandColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                  CustomButton(
                    text: "Continue",
                    onClick: () {
                      Get.to(() => Verify());
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
