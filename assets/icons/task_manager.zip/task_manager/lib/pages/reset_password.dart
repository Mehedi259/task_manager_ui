import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:task_manager/pages/app.dart';
import 'package:task_manager/utils/app_colors.dart';
import 'package:task_manager/widgets/custom_button.dart';
import 'package:task_manager/widgets/custom_textfield.dart';

class ResetPassword extends StatelessWidget {
  const ResetPassword({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Align(
        alignment: Alignment.center,
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsetsGeometry.symmetric(horizontal: 16.h),
            child: Column(
              spacing: 23.h,
              children: [
                Column(
                  children: [
                    Text(
                      "Set Your New Password",
                      style: TextStyle(
                        color: AppColors.primaryTextColor,
                        fontWeight: FontWeight.w500,
                        fontSize: 30.w,
                      ),
                    ),
                    SizedBox(height: 8.h),
                    Text(
                      "Create a secure password to protect your account and get started seamlessly!",
                      style: TextStyle(
                        color: AppColors.secondaryTextColor,
                        fontSize: 14.h,
                      ),
                    ),
                  ],
                ),
                CustomTextfield(title: "New Password", isPass: true),
                CustomTextfield(title: "Confirm Password", isPass: true),
                CustomButton(
                  text: "Continue",
                  onClick: () {
                    Get.to(() => App());
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
