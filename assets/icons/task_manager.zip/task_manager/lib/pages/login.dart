import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/instance_manager.dart';
import 'package:get/route_manager.dart';
import 'package:task_manager/controllers/task_controller.dart';
import 'package:task_manager/pages/signup.dart';
import 'package:task_manager/utils/app_colors.dart';
import 'package:task_manager/widgets/custom_button.dart';
import 'package:task_manager/widgets/custom_textfield.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  bool rememberMe = false;

  @override
  void initState() {
    super.initState();
    Get.put(TaskController());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Align(
        alignment: Alignment.center,
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.h),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Welcome Back!",
                  style: TextStyle(
                    color: AppColors.primaryTextColor,
                    fontWeight: FontWeight.w500,
                    fontSize: 30.w,
                  ),
                ),
                SizedBox(height: 8.h),
                Text(
                  "Stay productive and take control of your tasks.",
                  style: TextStyle(
                    color: AppColors.secondaryTextColor,
                    fontSize: 14.h,
                  ),
                ),
                SizedBox(height: 23.h),
                CustomTextfield(
                  title: "Email Address",
                  hintText: "michelle.rivera@example.com",
                ),
                SizedBox(height: 23.h),
                CustomTextfield(title: "PassWord", isPass: true),
                SizedBox(height: 2.h),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        setState(() {
                          rememberMe = !rememberMe;
                        });
                      },
                      behavior: HitTestBehavior.translucent,
                      child: SvgPicture.asset(
                        "assets/icons/${rememberMe ? "" : "un"}check.svg",
                      ),
                    ),
                    SizedBox(width: 6.h),
                    Text(
                      "Remember me",
                      style: TextStyle(
                        fontSize: 12.h,
                        color: Color(0xff344054),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 23.h),
                Row(
                  spacing: 8.h,
                  children: [
                    Expanded(
                      child: Divider(color: Color(0xff64748B), height: 1.5),
                    ),
                    Text(
                      "OR",
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 14.h,
                        color: Color(0xff0A0E23),
                      ),
                    ),
                    Expanded(
                      child: Divider(color: Color(0xff64748B), height: 1.5),
                    ),
                  ],
                ),
                SizedBox(height: 23.h),
                Row(
                  spacing: 4,
                  children: [
                    Text(
                      "Don’t have an account?",
                      style: TextStyle(
                        fontSize: 14.h,
                        color: Color(0xff344054),
                      ),
                    ),
                    GestureDetector(
                      onTap: () {
                        Get.to(() => Signup());
                      },
                      behavior: HitTestBehavior.translucent,
                      child: Text(
                        "Sign Up",
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          fontSize: 14.h,
                          color: AppColors.brandColor,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 23.h),
                CustomButton(
                  text: "Log In",
                  onClick: () {
                    Get.to(() => Signup());
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
