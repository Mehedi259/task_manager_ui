import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:task_manager/controllers/task_controller.dart';
import 'package:task_manager/models/task.dart';
import 'package:task_manager/utils/app_colors.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final taskController = Get.find<TaskController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.h),
        child: Column(
          children: [
            SafeArea(
              child: Padding(
                padding: EdgeInsets.only(top: 16.h, bottom: 24.h),
                child: Row(
                  children: [
                    ClipRRect(
                      child: Image.asset(
                        "assets/images/user.png",
                        height: 44.h,
                        width: 44.h,
                      ),
                    ),
                    SizedBox(width: 10.h),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Hello Mojahid",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        Text(
                          "Welcome to Task Manager ",
                          style: TextStyle(fontSize: 12.h),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "My Tasks",
                style: TextStyle(fontWeight: FontWeight.w500, fontSize: 18.h),
              ),
            ),
            SingleChildScrollView(
              child: Obx(
                () => Column(
                  children: [
                    for (var i in taskController.tasks) TaskWidget(task: i),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TaskWidget extends StatelessWidget {
  final Task task;
  const TaskWidget({super.key, required this.task});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: (MediaQuery.of(context).size.width - 32.h) * 0.3938,
      padding: EdgeInsets.all(20.h),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(6),
        image: DecorationImage(image: AssetImage("assets/images/task_bg.png")),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SvgPicture.asset("assets/icons/task.svg"),
          Spacer(flex: 3,),
          Text(
            task.title,
            style: TextStyle(
              fontWeight: FontWeight.w500,
              color: Color(0xff111827),
            ),
          ),
          Spacer(flex: 2,),
          Text(
            task.description,
            maxLines: 2,
            style: TextStyle(
              overflow: TextOverflow.ellipsis,
              fontSize: 12.h,
              color: AppColors.secondaryTextColor,
            ),
          ),
        ],
      ),
    );
  }
}
