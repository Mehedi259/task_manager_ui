import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:task_manager/pages/reset_password.dart';
import 'package:task_manager/utils/app_colors.dart';
import 'package:task_manager/widgets/custom_button.dart';

class Otp extends StatelessWidget {
  const Otp({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Align(
        alignment: Alignment.center,
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsetsGeometry.symmetric(horizontal: 16.h),
            child: Column(
              children: [
                Column(
                  children: [
                    Text(
                      "6-digit code",
                      style: TextStyle(
                        color: AppColors.primaryTextColor,
                        fontWeight: FontWeight.w500,
                        fontSize: 30.w,
                      ),
                    ),
                    SizedBox(height: 8.h),
                    Text(
                      "Please enter the code we've sent to michelle.rivera@example.com.",
                      style: TextStyle(
                        color: AppColors.secondaryTextColor,
                        fontSize: 14.h,
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 23.h),
                Pinput(
                  length: 6,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  defaultPinTheme: PinTheme(
                    height: 46.w,
                    width: 46.w,
                    textStyle: TextStyle(
                      color: AppColors.secondaryTextColor,
                      fontSize: 16.h,
                    ),
                    decoration: BoxDecoration(
                      color: AppColors.softBrandColor,
                      borderRadius: BorderRadius.circular(6),
                      boxShadow: [
                        BoxShadow(
                          offset: Offset(1, 1),
                          blurRadius: 24,
                          color: Colors.black.withValues(alpha: 0.1),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 60.h),
                CustomButton(
                  text: "Confirm",
                  onClick: () {
                    Get.to(() => ResetPassword());
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
