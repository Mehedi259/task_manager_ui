import 'package:flutter/widgets.dart';

class AppColors {
  static Color brandColor = Color(0xff84C000);
  static Color softBrandColor = Color(0xffF7FFEF);
  static Color primaryTextColor = Color(0xff111827);
  static Color secondaryTextColor = Color(0xff6B7280);
}
