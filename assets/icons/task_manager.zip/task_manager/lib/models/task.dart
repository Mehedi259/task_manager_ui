class Task {
  String title;
  String description;

  Task(this.title, this.description);
}
