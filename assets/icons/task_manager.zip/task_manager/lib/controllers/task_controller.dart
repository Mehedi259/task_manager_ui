import 'package:get/get.dart';
import 'package:task_manager/models/task.dart';

class TaskController extends GetxController {
  RxList<Task> tasks = RxList([
    Task(
      "Design Landing Page Header",
      "Create a clean, responsive header section with logo, navigation links, and a clear call-to-action button.",
    ),
  ]);

  void createTask(String title, String description) {
    tasks.add(Task(title, description));
  }

  void editTask(int index, String newTitle, String newDescription) {
    tasks[index].title = newTitle;
    tasks[index].description = newDescription;
  }

  void deleteTask(int index) {
    tasks.removeAt(index);
  }
}
